//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function mostrar()
{
 alert ("holaa");	
}


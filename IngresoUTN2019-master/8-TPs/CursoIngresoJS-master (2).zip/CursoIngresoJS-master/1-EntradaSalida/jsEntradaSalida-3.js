/*Debemos lograr tomar un dato por 'ID'
y luego mostrarlo por 'Alert' al presionar el botón  'MOSTRAR'*/
function mostrar()
{
	/*alert("ejercicio 3");
	console.log("esto no es un log");
	*/

	//console.info("ss ");
	var nombre;
	nombre=document.getElementById('elNombre').value;
	alert(nombre);

}



function Mostrar()
{
  var nombre;
  var ciudad;

  nombre= document.getElementById('elNombre').value;
  ciudad= document.getElementById("laLocalidad").value;

  alert("Usted es "+nombre+ " y vive en la localidad de "+ciudad);
}

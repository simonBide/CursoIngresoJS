function Mostrar()
{
	var precio;
	var porcentaje;
	var precioFinal;

  precio=prompt("el precio es");
  porcentaje=prompt("el descuento es");



	document.getElementById('elPrecioFinal').value = precioFinal;


}

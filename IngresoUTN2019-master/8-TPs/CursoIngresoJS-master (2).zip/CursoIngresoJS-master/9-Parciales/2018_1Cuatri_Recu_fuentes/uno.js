
function Mostrar()
{
	var lados
	var perimetro

	lados = document.getElementById('FormIngreso').value

  perimetro = lado
}

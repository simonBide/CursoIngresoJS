function Mostrar()
{

var clave = prompt("ingrese el número clave.");

 while (clave != "utn750"){
 	clave = prompt("ingrese el número clave.");
 
 }
alert("Contraseña correcta")

 }//FIN DE LA FUNCIÓN

function Mostrar()
{
	
	var contador = 10;

	while (contador >= 1){

	console.log (contador);

		contador -= 1;
	}



}//FIN DE LA FUNCIÓN
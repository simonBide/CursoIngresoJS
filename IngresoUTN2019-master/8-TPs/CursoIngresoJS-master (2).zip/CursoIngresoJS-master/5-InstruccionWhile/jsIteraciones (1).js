function Mostrar()
{
	var contador = 1;

	while (contador <= 10);{

	console.log (contador);

		contador =+ 1;
	}





}//FIN DE LA FUNCIÓN